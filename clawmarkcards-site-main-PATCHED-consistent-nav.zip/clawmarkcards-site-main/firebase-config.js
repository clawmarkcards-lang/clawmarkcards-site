// firebase-config.js
const firebaseConfig = {
  apiKey: "AIzaSyCM5La0C7dKpWgQUpAxVQguDcEV1D4Vmms",
  authDomain: "clawmarkcards-app.firebaseapp.com",
  projectId: "clawmarkcards-app",
  storageBucket: "clawmarkcards-app.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase (for compat)
firebase.initializeApp(firebaseConfig);
